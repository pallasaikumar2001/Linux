public class App {
    public static void main(String[] args) throws Exception {
        
    }
}

class MathOperations { 
    int add(int a, int b) {
         return a + b; 
    } 
    int add(int a) { 
        return a; 
    } 
}


