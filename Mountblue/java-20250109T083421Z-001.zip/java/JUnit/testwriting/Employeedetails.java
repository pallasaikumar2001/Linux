public class Employeedetails{
    private String name;
    private double monthsalary;
    private int age;

    public String getName(){
        return name;
    }

    public void setname(String name){
        this.name=name;
    }

    public double getmonthlysalary(){
        return monthsalary;
    }
    public void setmonthlysalary(double monthsalary){
        this.monthsalary=monthsalary;
    }
    public int getage(){
        return age;
    }
    public void setage(int age){
        this.age=age;
    }
}