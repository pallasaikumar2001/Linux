package org.example;

public class Main {
    public void main() {
        System.out.println("Hello world");
        for (int i=0;i<5;i++){
            System.out.println("i ="+i);
        }
    }
}