import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class maintest {
    public static void main(String[] args) {
        System.out.println("Running Test Cases using JUnit for Main class");
        Result result = JUnitCore.runClasses(Main.class);
        int c=0;
        for (Failure failure : result.getFailures()) {
            System.out.println("Test failed: " + failure.toString());
            System.out.println();
            c++;
        }

        if (result.wasSuccessful()) {
            System.out.println("All tests passed successfully!");
        } else {
            System.out.println(c + " test(s) failed.");
        }
    }
}
