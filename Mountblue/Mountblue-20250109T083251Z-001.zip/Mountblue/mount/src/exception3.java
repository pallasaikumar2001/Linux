// import java.io.*;
public class exception3 {
    public static void main(String[] args) {
        getFile("./sahja.txt");
    }
    public static void getFile(String filename){
        // try{
        //     FileInputStream file=new FileInputStream(filename);
        // }
        // catch (FileNotFoundException e){
        //     System.out.println("Sorry cannot find the file");
        // }
        // catch(IOException e){
        //     System.out.println("Unknown IO Error");
        // }
        // catch(Exception e){
        //     System.out.println("Some error is occured");
        // }
    }
        
}
