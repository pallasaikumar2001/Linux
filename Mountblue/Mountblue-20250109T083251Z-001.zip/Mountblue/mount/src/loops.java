import java.util.Scanner;

public class loops {
    static Scanner userInput=new Scanner(System.in);
    public static void main(String[] args) {
        // int i=1;
        // while (i<=20){
        //     System.out.println(i);
        //     if (i==3){
        //         i+=1;
        //         continue;
        //     }
        //     i++;
        //     if (i%2==0){
        //         i++;
        //     }
        //     if (i>10){
        //         break;
        //     }
        // }

        // String countYorN="Y";
        // int h=1;
        // while (countYorN.equalsIgnoreCase("y")){
        //     System.out.println(h);
        //     System.out.println("continue y or n? ");
        //     countYorN=userInput.nextLine();
        //     h++;
        // }


        // int k=200;
        // do{
        //     System.out.println(k);
        //     k++;

        // }while(k<=10);


        for (int i=1;i<=10;i++){
            System.out.println(i);
        }

    }
}
