public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        System.out.println("this is another content");
        String result="hello"+" "+"World";
        System.out.println(result);
        String str=Integer.toString(123);
        System.out.println(str);
        int number=Integer.parseInt("87437");
        System.out.println(number);
        char c=122;
        System.out.println(c);
        System.out.println("sai\\kumar");    
    }
}
