import React from "react";

function App() {
  const name = "Saikumar";
  const element = React.createElement("h1", null, "Hello");
  function alerting() {
    alert(`Button clicked by ${name}`);
  }
  const items = ["apple", "banana", "Cherry"];
  const users = [
    { id: 1, name: "Geeks", age: 30 },
    { id: 2, name: "for", age: 25 },
    { id: 3, name: "Geeks", age: 20 },
  ];
  return (
    <div>
      <h1>Hello, {name} !</h1>
      {element}
      <button onClick={alerting}>Click me</button>
      <h1>My Fruit List</h1>
      <ul>
        {items.map((item, index) => (
          <li>{item}</li>
        ))}
      </ul>

      <ul>
        {users.map((user, index) => (
          <li>
            {user.name} is {user.age} years old.
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
